# dev_aberto

Pacote Python para demonstração.

Repositório da disciplina: [link-para-repositorio-da-disciplina]
